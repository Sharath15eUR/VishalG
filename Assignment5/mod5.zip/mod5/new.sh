#!/bin/bash

echo "Executable file : $0"

if [ "$1"=="--help" ]; then
cat help.txt
exit 1
fi


if [[ ! $# -eq 2 ]]; then
echo "directory or keyword is missing"
exit 1
fi > error.log

list=()

recur() {
    local dir="$1"
    local keyword="$2"

    
    for file in "$dir"/*; do
        if [ -d "$file" ]; then
            search_files "$file" "$keyword"
        elif [ -f "$file" ]; then
            list+=("$file")
            if grep -q "$keyword" "$file"; then
                echo "Keyword found in: $file"
            fi
        fi
    done
}


recur "$1" "$2"

echo "List of searched files"
for file in "${list[@]}"; do
echo "$file"
done
