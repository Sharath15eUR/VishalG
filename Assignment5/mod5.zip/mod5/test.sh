#!/bin/bash

echo "Executable file : $0"

if [[ ! $# -eq 2 ]]; then
echo "directory or keyword is missing"
exit 1
fi > error.log
 
list=()

dir= "$1"
keyword= "$2"

recur(){

if [ ${#keyword} -eq 0 ]; then
echo "Invalid Keyword">error.log
exit 1
fi


for file in "$dir"/*; do
if [ ! -d "$file" ]; then
echo "No such directory" > error.log
fi

if [ -d "$file" ]; then
echo "$file"
recur "$file" "$keyword"
elif [ -f "$file" ]; then
list+=("$file")
if grep -q "$keyword" "$file"; then
echo "Keyword found in $file"
fi
fi

done 
}

recur "$1" "$2"
echo "List of searched files"
for file in "${list[@]}"; do
echo "$file"
done
